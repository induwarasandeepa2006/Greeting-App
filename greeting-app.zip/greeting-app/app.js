const express = require("express");
const app = express();

app.use(express.urlencoded({ extended: true }));

// Home page
app.get("/", function(req, res) {
  res.send("<h1>Welcome</h1>" +
  "<form action='/greet' method='POST'>" +
  "<input type='text' name='username' placeholder='Enter your name' required>" +
  "<button type='submit'>Submit</button>" +
  "</form>");
});

// POST request
app.post("/greet", function(req, res) {
  const name = req.body.username;
  res.redirect("/hello?name=" + name);
});

// GET request
app.get("/hello", function(req, res) {
  const name = req.query.name;
  res.send("<h1>Hello, " + name + "!</h1>");
});

// Start server
app.listen(3000, function() {
  console.log("Server running on http://localhost:3000");
});